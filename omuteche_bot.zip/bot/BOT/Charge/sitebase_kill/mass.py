
import asyncio
from .single import kill_card_logic

async def mass_kill_cards(message, cards):
    results = []
    for card in cards:
        try:
            cc, mes, ano, cvv = card.strip().split("|")
            result = await kill_card_logic(cc, mes, ano, cvv)
            results.append((card, result))
            await asyncio.sleep(1)
        except Exception as e:
            results.append((card, f"Error: {str(e)}"))
    return results
