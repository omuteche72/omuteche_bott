import aiohttp
import asyncio
import pycountry
import certifi
import ssl


async def get_bin_details(cc):
    fbin = cc[:6]  # Extract the first 6 digits of the card number

    async def fetch_bin_info_from_api(fbin):
        url = f"https://cheker.site/bins/?bin={fbin}"
        try:
            ssl_context = ssl.create_default_context(cafile=certifi.where())
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession() as session:
                async with session.get(url, ssl=ssl_context, timeout=timeout) as response:
                    if response.status == 200:
                        data = await response.json()
                        if data.get("status") == "success":
                            return data["data"]
                    else:
                        print(
                            f"Failed to fetch data. Status code: {response.status}")
        except Exception as e:
            print(f"Error fetching BIN details from API: {e}")
        return None

    try:
        # Fetch BIN details from API
        bin_info = await fetch_bin_info_from_api(fbin)

        if not bin_info:
            return "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A"

        # Extract details from the API response
        brand = bin_info.get("brand", "N/A").upper()
        card_type = bin_info.get("type", "N/A").upper()
        level = bin_info.get("category", "N/A").upper()
        bank = bin_info.get("issuer", {}).get("name", "N/A").upper()
        country_code = bin_info.get("country", {}).get("alpha2", "N/A").upper()
        flag = bin_info.get("country", {}).get("flag", "N/A")
        country_name = bin_info.get("country", {}).get("name", "N/A")
        currency = "N/A"

        # Get currency using pycountry
        if country_code != "N/A":
            country = pycountry.countries.get(alpha_2=country_code)
            if country:
                country_name = country.name
                currency_obj = pycountry.currencies.get(
                    numeric=country.numeric)
                if currency_obj:
                    currency = currency_obj.alpha_3

        return brand, card_type, level, bank, country_name, flag, currency

    except Exception as e:
        print(f"Error processing BIN details: {e}")
        return "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A"


async def main():
    cc = "5241051234567890"  # Sample card number
    brand, card_type, level, bank, country_name, flag, currency = await get_bin_details(cc)
    print(f"Brand: {brand}")
    print(f"Type: {card_type}")
    print(f"Level: {level}")
    print(f"Bank: {bank}")
    print(f"Country: {country_name}")
    print(f"Flag: {flag}")
    print(f"Currency: {currency}")

if __name__ == "__main__":
    asyncio.run(main())
